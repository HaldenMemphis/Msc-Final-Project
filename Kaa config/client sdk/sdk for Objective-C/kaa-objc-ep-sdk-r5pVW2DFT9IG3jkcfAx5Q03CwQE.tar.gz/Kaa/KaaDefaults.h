/*
 * Copyright 2014-2016 CyberVision, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef KaaDefaults_h
#define KaaDefaults_h

#define BUILD_VERSION           @"0.10.0"
#define BUILD_COMMIT_HASH       @""
#define TRANSPORT_POLL_DELAY    @"0"
#define TRANSPORT_POLL_PERIOD   @"10"
#define TRANSPORT_POLL_UNIT     @"1"
#define SDK_TOKEN               @"r5pVW2DFT9IG3jkcfAx5Q03CwQE"
#define APPLICATION_ID			@"1"
#define CONFIG_DATA_DEFAULT     @"Ag=="
#define APP_PREFIX              APPLICATION_ID@"."SDK_TOKEN
#define STATE_FILE_LOCATION     @"state.properties"

static NSString *CONFIG_SCHEMA_DEFAULT = @"eyJ0eXBlIjoiYXJyYXkiLCJpdGVtcyI6eyJ0eXBlIjoicmVjb3JkIiwibmFtZSI6ImRlbHRhVCIsIm5hbWVzcGFjZSI6Im9yZy5rYWFwcm9qZWN0LmNvbmZpZ3VyYXRpb24iLCJmaWVsZHMiOlt7Im5hbWUiOiJkZWx0YSIsInR5cGUiOlt7InR5cGUiOiJyZWNvcmQiLCJuYW1lIjoiQ29uZmlndXJhdGlvbiIsIm5hbWVzcGFjZSI6Im9yZy5rYWFwcm9qZWN0LmthYS5zY2hlbWEuTW9uaXRvciIsImZpZWxkcyI6W3sibmFtZSI6Ik1lc3NhZ2VTZW5kVGltZU1pbnMiLCJ0eXBlIjpbImludCIseyJ0eXBlIjoiZW51bSIsIm5hbWUiOiJ1bmNoYW5nZWRUIiwibmFtZXNwYWNlIjoib3JnLmthYXByb2plY3QuY29uZmlndXJhdGlvbiIsInN5bWJvbHMiOlsidW5jaGFuZ2VkIl19XSwiYnlfZGVmYXVsdCI6MX0seyJuYW1lIjoiX191dWlkIiwidHlwZSI6eyJ0eXBlIjoiZml4ZWQiLCJuYW1lIjoidXVpZFQiLCJuYW1lc3BhY2UiOiJvcmcua2FhcHJvamVjdC5jb25maWd1cmF0aW9uIiwic2l6ZSI6MTZ9LCJkaXNwbGF5TmFtZSI6IlJlY29yZCBJZCIsImZpZWxkQWNjZXNzIjoicmVhZF9vbmx5In1dLCJ2ZXJzaW9uIjoxLCJkaXNwbGF5TmFtZSI6IkNvbmZpZ3VyYXRpb24gVjEgKFNlbmQgRGF0YSBFdmVyeSAxIE1pbnMpIiwiZGVzY3JpcHRpb24iOiJBdXRvIGdlbmVyYXRlZCJ9XX1dfX0=";
static NSString *BOOTSTRAP_SERVERS = @"-1835393002:1456013202:1:AAABJjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAI+O6Q+0iL2CjvIPHa4/8sDevC21y46Md50IU7fwPDFvNH3WZ1qNPVlmEbETgoFhsQK4TImDl5FMEL2eWnz59/7ubzWX4CQT+y+oCG2JjVAw26esMoLgqvzZVZD32SROvjB0RBZ7CzI49qlL8ZBivenloPkDBCV3VEVV/5dzcFScLwmtXB9uFCVGTCIY4d9bbJkzdg39uPs7b2GdUX8k81oJ7cTtI09Ca5pOrxc4GIPv4zkgzMWvr7PdQP7bnavXXBxUrTnmK/aSHLnY7CqUF2F9ug8MxuQB8ZEqMAyyqzvZoqeAhO1AKYIxPdgnkWkF+Tp+YobjnvoJNumMaim28P0CAwEAAQAAAA0yMC4yNTQuMjUuMjI4AAAmoA==;-1835393002:-73777936:1:AAABJjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAI+O6Q+0iL2CjvIPHa4/8sDevC21y46Md50IU7fwPDFvNH3WZ1qNPVlmEbETgoFhsQK4TImDl5FMEL2eWnz59/7ubzWX4CQT+y+oCG2JjVAw26esMoLgqvzZVZD32SROvjB0RBZ7CzI49qlL8ZBivenloPkDBCV3VEVV/5dzcFScLwmtXB9uFCVGTCIY4d9bbJkzdg39uPs7b2GdUX8k81oJ7cTtI09Ca5pOrxc4GIPv4zkgzMWvr7PdQP7bnavXXBxUrTnmK/aSHLnY7CqUF2F9ug8MxuQB8ZEqMAyyqzvZoqeAhO1AKYIxPdgnkWkF+Tp+YobjnvoJNumMaim28P0CAwEAAQAAAA0yMC4yNTQuMjUuMjI4AAAmoQ==;";

#endif /* KaaDefaults_h */
